
Remote control for AudioPlayer